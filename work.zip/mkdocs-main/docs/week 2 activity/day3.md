- Creating circuit to control RFID where we used 
      - esp32 
      - buzzer
      - rfid
      - lcd
- It had to display the uid of rfid in lcd and beeps
      