- recreating a acircuit and we also joined it with a web dashboard for supervising the whole system where by we used 

    - Esp32
    - Buzzer
    - Breadboard
    - leds
    - RFID
    
