- We started another module WAN 
     - Where by we created a lan of 3 departements to allow communication between all the computers in the network and also allow the file sharing 
    ![](../images/lan1.png)
- we also prototyped the smart home iot where by the server and   configure it's connectivity and register all the smart devices to the server for smart controlling 
      - And where smart phone controlls the the led ,the fan and also the door
      ![](../images/lan2.png)