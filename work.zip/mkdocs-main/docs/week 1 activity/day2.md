- Day 2 we had to do some simpl iot projects where by the we did the simple security system that involved the following components:  
      - Ultrasonic: For distance detaction
      - The buzzer: For alerts
      - The led: For also lighting 
      - Lcd: For user interaction
![]()
- Day 2 we also did the smart traffic system that involved the following components:  
      - 3 Leds: Green,Yellow,Red