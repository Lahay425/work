- Todays date we worked on an Iot project where by we had to design and implement the RFID-based server room control system with the lCD feed back 
    - Where by only 3 cards will be allowed to control and enter/access the system and the 
         - First card will have to be assigned there the ceo and after it display it in the lcd
         - second card will have to be displayed their the executive manager
         - third one the card will display the secretary that welcome in the lcd
    - This was the first operation/working where by we had to use the rfid to scan the cards and it is true it dipslay that welcome...... the name of the user of the card and if it is wrong it displays access denied 
    ![](../images/rifdiwithoutled.jpg)
    - This was the second operation/working where by we had to use the rfid to scan the cards and it is true it dipslay that welcome...... and the led blue it turns on alwys if there is power in the sytem and the green led turns on if the access is granted the green led is turned on and also if the access is denied the redled turns on automatically
    ![](../images/securitycontrolusingledsandrfid.jpg)
    - This was the blue led indicating that the system is on <img src="/images/withled.jpg" width="200">
    