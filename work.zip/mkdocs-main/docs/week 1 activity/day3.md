- Today we created the project where we worked on the smart security control it included following components:
     - servomotor: For opening the door if the acces is granted 
     - Buzzer: For sound alert if the password is wrong
     - Keypad: Provides an interface for typing passwords
     - Lcd: For displaying the typing password.

![](../images/securitycontrol.png)